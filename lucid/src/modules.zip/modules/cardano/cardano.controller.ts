import {Controller, Post, Req} from "@nestjs/common";
import {Request} from "express";

@Controller('lido-minute')
export class CardanoController {
    @Post('mint')
    public async mintNft(@Req() request: Request) {

    }
}